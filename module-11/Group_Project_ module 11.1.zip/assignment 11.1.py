
import mysql.connector

# Group name: Puna Poudel / Zachary Brown 
# Assignment: module 11.1
# professor: Chandra Bobba
# due date: 07/21/2024

def generate_equipment_sales_report(cursor):
    query = """
    SELECT Sales.SaleID, Customers.Name AS CustomerName, Equipment.Name AS EquipmentName, Sales.SaleDate
    FROM Sales
    JOIN Customers ON Sales.CustomerID = Customers.CustomerID
    JOIN Equipment ON Sales.EquipmentID = Equipment.EquipmentID;
    """
    cursor.execute(query)
    results = cursor.fetchall()
    print("\n-- Equipment Sales Report --")
    for row in results:
        print(f"SaleID: {row[0]}, Customer: {row[1]}, Equipment: {row[2]}, Sale Date: {row[3]}")

def generate_trip_bookings_by_location_report(cursor):
    query = """
    SELECT Locations.Name AS LocationName, COUNT(Bookings.BookingID) AS NumberOfBookings
    FROM Bookings
    JOIN Trips ON Bookings.TripID = Trips.TripID
    JOIN Locations ON Trips.LocationID = Locations.LocationID
    GROUP BY Locations.Name;
    """
    cursor.execute(query)
    results = cursor.fetchall()
    print("\n-- Trip Bookings by Location Report --")
    for row in results:
        print(f"Location: {row[0]}, Number of Bookings: {row[1]}")

def generate_aged_inventory_report(cursor):
    query = """
    SELECT Equipment.EquipmentID, Equipment.Name, Equipment.PurchaseDate
    FROM Equipment
    WHERE PurchaseDate < DATE_SUB(CURDATE(), INTERVAL 5 YEAR);
    """
    cursor.execute(query)
    results = cursor.fetchall()
    print("\n-- Aged Inventory Report --")
    for row in results:
        print(f"EquipmentID: {row[0]}, Name: {row[1]}, Purchase Date: {row[2]}")

# Database connection
config = {
    'user': 'root',  
    'password': 'root',  
    'host': '127.0.0.1',
    'database': 'outland_adventures',
    'raise_on_warnings': True
}

try:
    db = mysql.connector.connect(**config)
    cursor = db.cursor()

    generate_equipment_sales_report(cursor)
    generate_trip_bookings_by_location_report(cursor)
    generate_aged_inventory_report(cursor)

except mysql.connector.Error as err:
    print("Error:", err)
finally:
    if db.is_connected():
        cursor.close()
        db.close()
