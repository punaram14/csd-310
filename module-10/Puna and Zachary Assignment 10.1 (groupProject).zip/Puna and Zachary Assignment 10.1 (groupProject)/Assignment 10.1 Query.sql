-- Select the existing database
USE outland_adventures;

-- Drop tables if they already exist to avoid conflicts
DROP TABLE IF EXISTS Customers, Trips, Guides, Equipment, Sales, Rentals, Employees, Supplies, Bookings, Locations;

-- Create Customers Table
CREATE TABLE Customers (
    CustomerID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100),
    Address VARCHAR(255),
    Phone VARCHAR(20),
    Email VARCHAR(100)
);

-- Create Guides Table
CREATE TABLE Guides (
    GuideID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100),
    Expertise VARCHAR(100)
);

-- Create Locations Table
CREATE TABLE Locations (
    LocationID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100),
    Description TEXT,
    BookingTrend VARCHAR(100)
);

-- Create Trips Table
CREATE TABLE Trips (
    TripID INT AUTO_INCREMENT PRIMARY KEY,
    LocationID INT,
    Date DATE,
    GuideID INT,
    FOREIGN KEY (LocationID) REFERENCES Locations(LocationID),
    FOREIGN KEY (GuideID) REFERENCES Guides(GuideID)
);

-- Create Equipment Table
CREATE TABLE Equipment (
    EquipmentID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100),
    Type VARCHAR(100),
    PurchaseDate DATE,
    Status VARCHAR(20)
);

-- Create Sales Table
CREATE TABLE Sales (
    SaleID INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID INT,
    EquipmentID INT,
    SaleDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (EquipmentID) REFERENCES Equipment(EquipmentID)
);

-- Create Rentals Table
CREATE TABLE Rentals (
    RentalID INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID INT,
    EquipmentID INT,
    RentalDate DATE,
    ReturnDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (EquipmentID) REFERENCES Equipment(EquipmentID)
);

-- Create Employees Table
CREATE TABLE Employees (
    EmployeeID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100),
    Role VARCHAR(100),
    Department VARCHAR(100)
);

-- Create Supplies Table
CREATE TABLE Supplies (
    SupplyID INT AUTO_INCREMENT PRIMARY KEY,
    TripID INT,
    EquipmentID INT,
    Quantity INT,
    FOREIGN KEY (TripID) REFERENCES Trips(TripID),
    FOREIGN KEY (EquipmentID) REFERENCES Equipment(EquipmentID)
);

-- Create Bookings Table
CREATE TABLE Bookings (
    BookingID INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID INT,
    TripID INT,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (TripID) REFERENCES Trips(TripID)
);

-- Insert Sample Data into Customers
INSERT INTO Customers (Name, Address, Phone, Email) VALUES
('John Doe', '123 Main St', '555-555-5555', 'john@example.com'),
('Jane Smith', '456 Elm St', '555-555-1234', 'jane@example.com'),
('Alice Johnson', '789 Oak St', '555-555-7890', 'alice@example.com'),
('Bob Brown', '321 Pine St', '555-555-4567', 'bob@example.com'),
('Charlie Black', '654 Maple St', '555-555-6543', 'charlie@example.com'),
('Diana Green', '987 Cedar St', '555-555-9876', 'diana@example.com');

-- Insert Sample Data into Guides
INSERT INTO Guides (Name, Expertise) VALUES
('John MacNell', 'Mountain Hiking'),
('D.B. Marland', 'Desert Trekking');

-- Insert Sample Data into Locations
INSERT INTO Locations (Name, Description, BookingTrend) VALUES
('Africa', 'Safari Adventures', 'Stable'),
('Asia', 'Cultural Treks', 'Increasing'),
('Southern Europe', 'Historic Sites', 'Decreasing');

-- Insert Sample Data into Trips
INSERT INTO Trips (LocationID, Date, GuideID) VALUES
(1, '2023-05-01', 1),
(2, '2023-06-15', 2),
(3, '2023-07-20', 1);

-- Insert Sample Data into Equipment
INSERT INTO Equipment (Name, Type, PurchaseDate, Status) VALUES
('Tent', 'Shelter', '2020-01-01', 'Available'),
('Backpack', 'Gear', '2020-02-15', 'Available'),
('Sleeping Bag', 'Gear', '2020-03-10', 'Available'),
('Camping Stove', 'Cooking', '2020-04-20', 'Available'),
('Lantern', 'Lighting', '2020-05-30', 'Available'),
('First Aid Kit', 'Safety', '2020-06-25', 'Available');

-- Insert Sample Data into Sales
INSERT INTO Sales (CustomerID, EquipmentID, SaleDate) VALUES
(1, 1, '2021-01-10'),
(2, 2, '2021-02-20'),
(3, 3, '2021-03-15'),
(4, 4, '2021-04-25'),
(5, 5, '2021-05-30'),
(6, 6, '2021-06-20');

-- Insert Sample Data into Rentals
INSERT INTO Rentals (CustomerID, EquipmentID, RentalDate, ReturnDate) VALUES
(1, 1, '2022-01-10', '2022-01-15'),
(2, 2, '2022-02-20', '2022-02-25'),
(3, 3, '2022-03-15', '2022-03-20'),
(4, 4, '2022-04-25', '2022-04-30'),
(5, 5, '2022-05-30', '2022-06-05'),
(6, 6, '2022-06-20', '2022-06-25');

-- Insert Sample Data into Employees
INSERT INTO Employees (Name, Role, Department) VALUES
('Anita Gallegos', 'Marketing Specialist', 'Marketing'),
('Dimitrios Stravopolous', 'Supply Manager', 'Supply'),
('Mei Wong', 'Ecommerce Developer', 'IT'),
('Blythe Timmerson', 'Co-Founder', 'Administration'),
('Jim Ford', 'Co-Founder', 'Administration');

-- Insert Sample Data into Supplies
INSERT INTO Supplies (TripID, EquipmentID, Quantity) VALUES
(1, 1, 5),
(2, 2, 3),
(3, 3, 4);

-- Insert Sample Data into Bookings
INSERT INTO Bookings (CustomerID, TripID) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 1),
(5, 2),
(6, 3);

-- Verify Tables
SHOW TABLES;





USE outland_adventures;

-- Show data from Customers
SELECT * FROM Customers;
-- Show data from Guides
SELECT * FROM Guides;
-- Show data from Locations
SELECT * FROM Locations;
-- Show data from Trips
SELECT * FROM Trips;
-- Show data from Equipment
SELECT * FROM Equipment;
-- Show data from Sales
SELECT * FROM Sales;
-- Show data from Rentals
SELECT * FROM Rentals;
-- Show data from Employees
SELECT * FROM Employees;
-- Show data from Supplies
SELECT * FROM Supplies;
-- Show data from Bookings
SELECT * FROM Bookings;
